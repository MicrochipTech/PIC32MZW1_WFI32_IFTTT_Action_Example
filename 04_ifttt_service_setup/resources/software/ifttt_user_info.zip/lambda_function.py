import redis
import json
import requests
import time
from jose import jwk, jwt
from jose.utils import base64url_decode
import logging
import copy
import os
import pymysql


userpool_region = os.environ['USER_POOL_REGION']
userpool_id = os.environ['USER_POOL_ID']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

error_value = {
    "errors": [
        {
            "message": "Something went wrong!"
        }
    ]
}

        
user_info_value = {
    "data": {
        "name": "WFI32 IFTTT demo",
        "id": "WFI32-IoT",
        "url": "https://github.com/MicrochipTech/WFI32-IoT"
    }
}

#validate the JWT passed by the user
def validateToken(token):
    logger.info(token)
    app_client_id = os.environ['USER_POOL_APP_CLIENT_ID']

    keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(userpool_region, userpool_id)
    req = requests.get(keys_url)
    keys = req.json()["keys"]
    #keys=[{"alg":"RS256","e":"AQAB","kid":"eHtijpiZ+V9+2GcNoNWdoH8/7fDRm9etVuRh+4DJCsk=","kty":"RSA","n":"6R9JB1ZMuHvhOxTrmYdkDYDbhLcpaqISkXw3Y3Ozv1h44ZlwalCvTPsEnWNkU4zMi1-MoPs_IIboGqQmyd9m6zJHNgE8c4KhOGzpQbI-qOV5v-NIYWIv06qbAqJL6HbiOjf-XkaDAK-sewWDMfPnacuoIYolNdzpm9jnGxs54PKiOZR2fXJRSorSOp_XaqtBpFvQLi3tBz_LfIGkmct-vFdH4AjmkjOJeqWw22w-ljtOY-mnxnDz-bv0vePaSDiJWwyKodXTV4RdpwyaVzkrq3fMXdU4oBblx4Ns314NgkQIp8Upvif7ev0PVAhnfabPo5UfHVdM-NphUXYnuXg_Rw","use":"sig"},{"alg":"RS256","e":"AQAB","kid":"np7Kfx2pnnFC1rgyhJFUxNnfPbrwx87l5uqQEfAygrc=","kty":"RSA","n":"0aEPc8M-CwyLMRWt9y4XhTBQIyh526_2L9LBbD0OZHFjUJx29QmMaHaD3vNYzo9xLLgmg9TcXLbanO7g-v7VrSvNbJNg3bkiiBZFVSZX-M7dtFvSEMjp5Epc6kY4SMW-OC0kF9II5AD87EPSjd9d8XmX3Zuzl-l1qxuXgPtqy2524nWdWIwsqzEggU5tp4aFbu9mgx9KVTBWncwjrjfkfkJMsg0owEZqcwzkq43QNMeQrs3FI4pLmgUzFJtaI9cunH-umQO-_2RF-kb4f8rUfsWO1c5fECFtNhPfDrtziRMVpxg6kXpMdYYItAmftcC6YxyxJ1deDj0zdNwcl4X4ww","use":"sig"}]

    # get the kid from the headers prior to verification
    try:
        headers = jwt.get_unverified_headers(token)
    except:
        logger.info("token is invalid")
        return False
    kid = headers['kid']
    logger.error(kid)
    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break
    if key_index == -1:
        logger.error('Public key not found in jwks.json')
        return False
    # construct the public key
    public_key = jwk.construct(keys[key_index])
    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)
    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    # verify the signature
    if not public_key.verify(message.encode("utf8"), decoded_signature):
        logger.error('Signature verification failed')
        return False
    print('Signature successfully verified')
    # since we passed the verification, we can now safely
    # use the unverified claims
    claims = jwt.get_unverified_claims(token)
    # additionally we can verify the token expiration
    if time.time() > claims['exp']:
        logger.error('Token is expired')
        return False
    # and the Audience  (use claims['client_id'] if verifying an access token)
    logger.info(claims)
    if claims['client_id'] != app_client_id:
        logger.error('Token was not issued for this audience')
        return False
    # now we can use the claims
    logger.info(claims)
    return claims




def lambda_handler(request,context):
    
    logger.info(json.dumps(request))
    authToken=request["headers"]["authorization"];
    
    #validate auth token
    claims=validateToken(authToken.split()[1]);

    if not claims:
        return {
            "statusCode": 401,
            "headers": {
                "Content-Type": "application/json; charset=utf-8"     
            },
            "body": json.dumps(error_value)
        }


    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json; charset=utf-8"     
        },
        "body": json.dumps(user_info_value)
        
    }
    return response