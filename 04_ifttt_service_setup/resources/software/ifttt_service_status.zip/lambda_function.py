import json
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(request, context):
    
    logger.info(json.dumps(request))
    
    channelKey=request["headers"]["ifttt-channel-key"];
    serviceKey=request["headers"]["ifttt-service-key"];
    
    key = os.environ['IFTTT_SERVICE_KEY']

    
    if channelKey == key :
        statusCode = 200
    else:
        statusCode = 401
        
    return {
        'statusCode': statusCode,
    }
