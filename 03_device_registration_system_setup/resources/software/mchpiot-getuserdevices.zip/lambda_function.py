import redis
import json
import requests
import time
from jose import jwk, jwt
from jose.utils import base64url_decode
import logging
import copy
import os
import pymysql

rds_host  = os.environ['DB_INSTANCE']
name = os.environ['DB_USER_NAME']
password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']
userpool_region = os.environ['USER_POOL_REGION']
userpool_id = os.environ['USER_POOL_ID']

logger = logging.getLogger()
logger.setLevel(logging.INFO)


#validate the JWT passed by the user
def validateToken(token):
    
    app_client_id = os.environ['USER_POOL_APP_CLIENT_ID']

    #keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(userpool_region, userpool_id)
    #req = requests.get(keys_url)
    #keys = req.json()["keys"]
    
    keys=[{"alg":"RS256","e":"AQAB","kid":"JxJ3b0PUdJWzCGTnOjVHHJ38fsmnolZfx1tPQCMlFD0=","kty":"RSA","n":"t22iDNJykmZu5iebpkjQcC4HZGNttJmxVKqTPo1MGJQPmIDCHTRwiiMkG8CCpVn_k1O8HrtELyYJgssrunpjekiIfY3np3RLGJblOIZxnbq8s78z0JoJtfird29oxZItGDYfuSQz2ptQ5Hx8FsVIvd3T9hP5sGabewsdQTpSlv5LKkTV6doyad1ktnrD_avolxUhtvCwioRRdx7rUxiUXsW0e108ExljYvnnJtAXH_pc-cwaasOT74KO3g9U_u-hIa_9oK25trDz5dS1eMFNr5uAk1LBuH9-0ml_VxHGA1HPb5W5gIKBpsSIgL6Uwbg33kLmKq_of2nctPDLa7DA4Q","use":"sig"},{"alg":"RS256","e":"AQAB","kid":"af0DjIq6FxPyt76m6Xg0jddJsTaezntTt3G5CoxP5pA=","kty":"RSA","n":"zlKcKJaWfmSEp6nS9lSjlS6ycNl2LoyELw13r2VN9lTLNgGNiAR8d8ObEOmF0fYeZLo7fzweken70Dl0BjKAm2gujeGYB-TOJIxQAhdGkOGW4SxgOISssIXUkXyJ1xIuB_rec47ElRU9oXHfGV9_MPT0MShU1N9C2Y8YgCDasl5kMsWUtP5N07Z0yUG4_FIqyt4WMpwzWxpuOTwnA4hw1IMvTOIi9XyQiLerJ4P5aQBLljqNFi6FpEnWKH2wVBsTWGS3na_bvnt3Rbn2M9f1GZXWVBPnBS2UceCoJ1ugJJaesPR6CJ5-zAnCrhuvP1qooRB0LYC2dQRjAFQ9HP5MTw","use":"sig"}]

    # get the kid from the headers prior to verification
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']
    logger.error(kid)
    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break
    if key_index == -1:
        logger.error('Public key not found in jwks.json')
        return False
    # construct the public key
    public_key = jwk.construct(keys[key_index])
    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)
    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    # verify the signature
    if not public_key.verify(message.encode("utf8"), decoded_signature):
        logger.error('Signature verification failed')
        return False
    print('Signature successfully verified')
    # since we passed the verification, we can now safely
    # use the unverified claims
    claims = jwt.get_unverified_claims(token)
    # additionally we can verify the token expiration
    if time.time() > claims['exp']:
        logger.error('Token is expired')
        return False
    # and the Audience  (use claims['client_id'] if verifying an access token)
    if claims['aud'] != app_client_id:
        logger.error('Token was not issued for this audience')
        return False
    # now we can use the claims
    logger.info(claims)
    return claims

def getUserDeviceList(username):
    
    res_dct = dict()
    
    try:
        conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        return res_dct

    logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
    
    with conn.cursor() as cur:
        cur.execute("create table if not exists DeviceList1 ( UserName varchar(255) NOT NULL, ThingName varchar(255) NOT NULL, PRIMARY KEY (UserName, ThingName))")

        sql="select * from DeviceList1 where UserName='%s'" % (username)
        cur.execute(sql)
        
        for row in cur:
            res_dct[row[1]] = row[1]
            #for x in res_dct.values():
            #    logger.info(x)

    conn.commit()
    
    return res_dct


def lambda_handler(request,context):
    
    logger.info(json.dumps(request))
    authToken=request["headers"]["auth-token"];
    
    #validate auth token
    
    claims=validateToken(authToken);

    if not claims:
        return {
            "statusCode": 401
        }
    else:
        username=claims["cognito:username"].strip()
        deviceList=getUserDeviceList(username)
        return deviceList
    